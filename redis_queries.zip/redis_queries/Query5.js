// Query5

import { MongoClient } from "mongodb";
import { createClient } from "redis";

const mongoClient = new MongoClient("mongodb://localhost:27017");
const redisClient = createClient();

redisClient.on("error", (err) => console.error("Redis error:", err));

async function main() {
  await mongoClient.connect();
  await redisClient.connect();

  const db = mongoClient.db("ieeevisTweets");
  const tweets = db.collection("tweet");

  const cursor = tweets.find(
    {},
    {
      projection: {
        id_str: 1,
        text: 1,
        created_at: 1,
        favorite_count: 1,
        retweet_count: 1,
        "user.screen_name": 1,
        "user.name": 1,
        "user.followers_count": 1,
      },
    }
  );

  let processed = 0;

  for await (const tweet of cursor) {
    const screenName = tweet.user?.screen_name;
    const tweetId = tweet.id_str || String(tweet._id);

    if (!screenName || !tweetId) continue;

    await redisClient.rPush(`tweets:${screenName}`, tweetId);

    await redisClient.hSet(`tweet:${tweetId}`, {
      id: tweetId,
      user_name: tweet.user?.name ?? "",
      screen_name: screenName,
      text: tweet.text ?? "",
      created_at: tweet.created_at ?? "",
      favorite_count: String(tweet.favorite_count ?? 0),
      retweet_count: String(tweet.retweet_count ?? 0),
      followers_count: String(tweet.user?.followers_count ?? 0),
    });

    processed++;
    if (processed % 1000 === 0) {
      console.log(`  Processed ${processed} tweets...`);
    }
  }

  console.log(`\nDone! Stored data for ${processed} tweets.`);
}
main()
  .catch(console.error)
  .finally(async () => {
    await mongoClient.close();
    await redisClient.quit();
  });