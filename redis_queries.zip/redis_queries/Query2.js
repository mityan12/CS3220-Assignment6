// Query2

import { MongoClient } from "mongodb";
import { createClient } from "redis";

const mongoClient = new MongoClient("mongodb://localhost:27017");
const redisClient = createClient();

redisClient.on("error", (err) => console.error("Redis error:", err));

async function main() {
  await mongoClient.connect();
  await redisClient.connect();

  const db = mongoClient.db("ieeevisTweets");
  const tweets = db.collection("tweet");

  await redisClient.set("favoritesSum", 0);
  const cursor = tweets.find({}, { projection: { favorite_count: 1 } });

  for await (const tweet of cursor) {
    const favs = tweet.favorite_count;
    if (favs && favs > 0) {
      await redisClient.incrBy("favoritesSum", favs);
    }
  }

  const total = await redisClient.get("favoritesSum");
  console.log(`Total number of favorites: ${total}`);
}

main()
  .catch(console.error)
  .finally(async () => {
    await mongoClient.close();
    await redisClient.quit();
  });