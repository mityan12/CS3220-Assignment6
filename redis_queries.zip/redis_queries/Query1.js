// Query1

import { MongoClient } from "mongodb";
import { createClient } from "redis";

const mongoClient = new MongoClient("mongodb://localhost:27017");
const redisClient = createClient();

redisClient.on("error", (err) => console.error("Redis error:", err));

async function main() {
  await mongoClient.connect();
  await redisClient.connect();

  const db = mongoClient.db("ieeevisTweets");
  const tweets = db.collection("tweet");

  await redisClient.set("tweetCount", 0);

  const cursor = tweets.find({}, { projection: { _id: 1 } });

  for await (const _ of cursor) {
    await redisClient.incr("tweetCount");
  }

  const count = await redisClient.get("tweetCount");
  console.log(`There were ${count} tweets`);
}

main()
  .catch(console.error)
  .finally(async () => {
    await mongoClient.close();
    await redisClient.quit();
  });