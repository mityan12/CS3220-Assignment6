// Query3

import { MongoClient } from "mongodb";
import { createClient } from "redis";

const mongoClient = new MongoClient("mongodb://localhost:27017");
const redisClient = createClient();

redisClient.on("error", (err) => console.error("Redis error:", err));

async function main() {
  await mongoClient.connect();
  await redisClient.connect();

  const db = mongoClient.db("ieeevisTweets");
  const tweets = db.collection("tweet");

  await redisClient.del("screen_names");

  const cursor = tweets.find({}, { projection: { "user.screen_name": 1 } });

  for await (const tweet of cursor) {
    const screenName = tweet.user?.screen_name;
    if (screenName) {
      await redisClient.sAdd("screen_names", screenName);
    }
  }

  const distinctCount = await redisClient.sCard("screen_names");
  console.log(`There are ${distinctCount} distinct users in the dataset`);
}

main()
  .catch(console.error)
  .finally(async () => {
    await mongoClient.close();
    await redisClient.quit();
  });